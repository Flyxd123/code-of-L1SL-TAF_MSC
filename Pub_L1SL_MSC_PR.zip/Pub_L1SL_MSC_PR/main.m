%function main()
clear all
clc

 load NH_interval9_mtv;



num_views = length(X);
N=length(gt);
numClust = length(unique(gt));

%%=========%%
for i=1:num_views
%     XX{i}=X{i};
    XX{i}=NormalizeData(X{i});
    d(i)=size(XX{i},1);
end
clear i
N = size(X{1},2);
D=sum(d);
x = tensor_construct(XX);
w = ones(1,num_views)';
%%%%Calculate S==================%


[S E conv1 conv3]=tensor_TLRRG_2p_new(XX,x,0.05,0.01,num_views,D,N,0.98); 

%%====clustering===========
  Z = 0;
for k=1:num_views
    Z = Z + (abs(S(:,:,k))+abs(S(:,:,k)'))./2;
end
Z = Z./num_views;
C = SpectralClustering(Z,numClust);
t1 =  ClusteringMeasure(gt,C);

