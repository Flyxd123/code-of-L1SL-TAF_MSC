function [Z E conv1 conv3]=tensor_TLRRG_2p_new(XX,x,lambda,beta,nV,sum_d,N,pp)
%%min||Q||_taf+lambda*||C^v||_1+beta*||E||_{2,p}S.T.
%%X=X*Z+E,Q=Z^,C^v=P^v(A^v)',P^v=Z^v
max_iter=200;
sX = [N, N, nV];
Isconverg = 0;
epson = 1e-5;
iter = 0;


% [SS]=t_SVD(XX,0.01,nV,N);
% for i=1:nV
%     s(:,:,i)=SS{i};
% end
% % 
% %construct K
% for k=1:nV
%     Weight{k} = constructW_PKN(abs(s(:,:,k))+abs(s(:,:,k)')./2, 5);
%     A{k}=Weight_vector(Weight{k},N);
% end
% % load A_yableB;
load A0point2_NH;

% load A0001_SC;
tau = 10e-5; tau_max = 10e10; pho_tau = 1.8;

%%%构造Z
Z = zeros(N,N,nV);
P = zeros(N,N,nV);
T = zeros(N,N,nV);
E = zeros(sum_d,N,nV);
Q = zeros(N,N,nV);
Y = zeros(sum_d,N,nV);
W = zeros(N,N,nV);
for i=1:nV
    C{i}=zeros(N,size(A{i},1));
    B{i}=zeros(N,size(A{i},1));
end
clear i
 
while (Isconverg == 0)
     z_vector = Z(:);
     w_vector = W(:);
     z_old =z_vector;
     q_old = Q(:);   
     e_old = E(:);
     %%====update Q====%       
    [q_vector, objV] = wshrinkObj(z_vector - (w_vector./tau),tau,sX,0,3);    
    Q = reshape(q_vector, sX);
    
    %%=====update Z=====% 
    mm= x-E+Y./tau;
    nn = P+T./tau;
    tt = Q+W./tau;
    Mhat = fft(mm,[],3);
    Xhat = fft(x,[],3);
    Nhat = fft(nn,[],3);
    That = fft(tt,[],3);
    for i=1:nV
        shat(:,:,i) = inv(tau*Xhat(:,:,i)'*Xhat(:,:,i)+(tau+tau)*eye(N,N))*(tau*Xhat(:,:,i)'*Mhat(:,:,i)+tau*Nhat(:,:,i)+tau*That(:,:,i));
    end
    clear i
    Z = ifft(shat,[],3); 
    %%====update E,Y,W=====%%
       for i=1:nV
           tempXZ(:,:,i)=Xhat(:,:,i)*shat(:,:,i);
       end
       clear i
        x_con_z = ifft(tempXZ,[],3);
       for i=1:nV
            E(:,:,i) = solve_l2p(x(:,:,i)- x_con_z(:,:,i)+Y(:,:,i)./tau,beta/tau,pp);
       end
       clear i 
       Y = Y+tau*(x-x_con_z-E);    
       W = W+tau*(Q-Z);
   %==========update C,P(A),B,T==========%%
       for i=1:nV
           C{i}=errormin(B{i},A{i},P(:,:,i),lambda,tau,1);
           temp_t1=C{i}+B{i}./tau;
           temp_t2=Z(:,:,i)-T(:,:,i)./tau;          
           P(:,:,i)=(tau*temp_t1*A{i}+tau*temp_t2)*inv(tau*A{i}'*A{i}+tau*eye(N,N)); 
           B{i}=B{i}+tau*(C{i}-P(:,:,i)*A{i}');           
       end
       clear i
       T = T+tau*(P-Z);
       
    
    %%====update tau======%%
    tau = min(tau*pho_tau, tau_max);
     
      
       con_1 = x-x_con_z-E;
       con_3 = Q-Z;
       
 

    tem_con = [norm(con_1(:),'inf'),norm(con_3(:),'inf')];
    if (iter>300) | max(tem_con)<=epson
        Isconverg  = 1;
    end
    iter = iter + 1;
    conv1(iter) = norm(con_1(:),'inf');
    conv3(iter) = norm(con_3(:),'inf');     
end