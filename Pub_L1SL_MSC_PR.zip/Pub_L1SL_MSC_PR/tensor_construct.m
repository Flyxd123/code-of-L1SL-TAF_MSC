function x_tensor=tensor_construct(X)

nV = length(X);
N = size(X{1},2);
for i=1:nV
    d(i)=size(X{i},1);
end
d_total=sum(d);
tem=zeros(d_total,nV);
x_tensor=zeros(d_total,N,nV);
for i=1:N
    tem(1:d(1),1)=X{1}(:,i);
    for j=2:nV
        tem(sum(d(1:j-1))+1:sum(d(1:j)),j)=X{j}(:,i);
    end
    x_tensor(:,i,:)=tem;
end
